#https://stackoverflow.com/questions/11680025/how-to-generate-random-number-without-repeat-in-database-using-php
#https://stackoverflow.com/questions/4429319/you-cant-specify-target-table-for-update-in-from-clause
#https://softwareengineering.stackexchange.com/questions/218306/why-not-expose-a-primary-key
#^^ this is my test/citation page for all the things ive learned to create unique random ID for the users
#in the first print
#this page doesnt really do anything like i said its my test page evverything else is on the functions and api page

from finalprojfunctions import (add_user, view_users, add_restaurants, view_all_restaurants, 
view_restaurant_id, edit_name, edit_restaurant, add_more_restaurants)
#add_user()
#view_users()
#add_restaurants() MAYBE REDUNDANT BC ADD MORE RESTAURANT CAN JUST DO THE SAME THING BUT BETTER
#view_all_restaurants()
#view_restaurant_id()
#edit_name()
#edit_restaurant()
#add_more_restaurants()

