import mysql.connector
from mysql.connector import Error
import random

#PETER NGUYEN AND DAN DOAN

#connection function
def create_connection(host_name, user_name, user_password, db_name):
    connection = None
    try:
        connection = mysql.connector.connect(
            host = host_name,
            user = user_name,
            password = user_password,
            database = db_name
        )
        print("Connection Established Successfully.")
    except Error as e:
        print(f"The error '{e} has occured.")
    return connection
conn = create_connection("cis3368.cnul0adngz4b.us-east-2.rds.amazonaws.com", "admin", "Weplaygames123!", "cis3368finalproject") #Info to connect to DB
cursor = conn.cursor(dictionary=True)

#add users function fixed
#this function will run a query and take the input from the api to add userid, firstname, and lastname to the users table.
def add_user(fname, lname):
    add = ("insert into users (userid, firstname, lastname)\n" 
        "values (\n"
        "(\n"
        "SELECT random_num\n"
        "FROM (   SELECT FLOOR(RAND() * 99999) AS random_num\n"
        "UNION\n"   
        "SELECT FLOOR(RAND() * 99999) AS random_num )\n"
        "AS numbers_mst_plus_1\n"
        "WHERE `random_num` NOT IN (SELECT userid FROM (SELECT * FROM users) AS newuse)\n"
        "LIMIT 1\n"
        f"), '{fname}', '{lname}')"
        )
    try:
        cursor.execute(add) #exucute query
        conn.commit()
    except Error as e: #if an error occured
        print(f"The error '{e}' occurred")
    print()

#add restaurants function fixed
#this function will run two queries, the first one inserts the input of the userid and restuarantn name into the resturant table.
#the 2nd query will find out how many resturants is added by the user.
def add_restaurants(userid, restaurantname):
    addrestaurants = (
    "insert into restaurants (userid, restaurantname)\n" #query
    f"values ('{userid}', '{restaurantname}')"
    )
    cursor.execute(addrestaurants)
    conn.commit()
    view = (
    "SELECT restaurants.restaurantname, restaurants.restaurantuniqueid, users.firstname, users.lastname\n" #query
    "FROM restaurants\n"
    "INNER JOIN users ON restaurants.userid=users.userid\n"
    f"WHERE users.userid = '{userid}'"
    )
    cursor.execute(view)
    rows = cursor.fetchall()
    try:
        cursor.execute(view)
        rows = cursor.fetchall()
    except Error as e:
        print(f"The error '{e}' occurred")
    count = len(rows)
    return count

#view restaurant added by userid fixed
#this function runs a query that uses the userid input to find the restuarants the user added.
def view_restaurant_id(userid):
    view = (
    "SELECT restaurants.restaurantname, restaurants.restaurantuniqueid, users.firstname, users.lastname\n" 
    "FROM restaurants\n"
    "INNER JOIN users ON restaurants.userid=users.userid\n"
    f"WHERE users.userid = '{userid}'"
    )
    try:
        cursor.execute(view)
        rows = cursor.fetchall()
    except Error as e:
        print(f"The error '{e}' occurred")
    return rows

#will return information of all the restaurant with their perspective userid and names
#this function runs a query that will find all the resturants info including firstname, lastname, userid, resturantid, and resturantname.
def view_restaurant_all_info():
    view = (
    "SELECT restaurants.restaurantname, restaurants.restaurantuniqueid, users.firstname, users.lastname, users.userid\n"
    "FROM restaurants\n"
    "INNER JOIN users ON restaurants.userid=users.userid\n"
    )
    try:
        cursor.execute(view)
        rows = cursor.fetchall()
    except Error as e:
        print(f"The error '{e}' occurred")
    return rows



#will return information of all the restaurant with their perspective userid and names
def view_restaurants():
    view = (
    "SELECT * FROM restaurants"
    )
    try:
        cursor.execute(view)
        rows = cursor.fetchall()
    except Error as e:
        print(f"The error '{e}' occurred")
    return rows

#change name by user fixed
#this function will take id, selection, fname, and lname input to run a query that edits either the first name or lastname depeding on the selection option.
def edit_name(id, selection, fname, lname):
    if selection == 1:
        update = ("UPDATE users\n"
        f"SET firstname = '{fname}'\n"
        f"WHERE userid = {id};"
        )
    if selection == 2:
        update = ("UPDATE users\n"
        f"SET lastname = '{lname}'\n"
        f"WHERE userid = '{id}';"
        )
    try:
        cursor.execute(update)
        conn.commit()
    except Error as e:
        print(f"The error '{e}' occurred")

#edit restuarant function
#this function will the userid and restaurantname input to run a query to change the restaurantname in the restaurants table.
def edit_restaurant(userid, restaurantid, newname):
    update = ("UPDATE restaurants\n"
    f"SET restaurantname = '{newname}'\n"
    f"WHERE restaurantuniqueid = {restaurantid} AND userid = {userid};"
    )
    try:
        cursor.execute(update)
        conn.commit()
    except Error as e:
        print(f"The error '{e}' occurred")

#del restaurant function
#this function has 2 queries, and it will use the userid and restaurantid to delete the row. It will run the 2nd query to find how restuarants (rows) the
#user has after deleting the row.
def delete_restaurant(userid, restaurantid):
    delete = ("DELETE FROM restaurants\n"
        f"WHERE restaurantuniqueid = {restaurantid} AND userid = {userid};"
    )
    try:
        cursor.execute(delete)
        conn.commit()
    except Error as e:
        print(f"The error '{e}' occurred")
    view = (
    "SELECT restaurants.restaurantname, restaurants.restaurantuniqueid, users.firstname, users.lastname\n"
    "FROM restaurants\n"
    "INNER JOIN users ON restaurants.userid=users.userid\n"
    f"WHERE users.userid = '{userid}'"
    )
    cursor.execute(view)
    rows = cursor.fetchall()
    try:
        cursor.execute(view)
        rows = cursor.fetchall()
    except Error as e:
        print(f"The error '{e}' occurred")
    count = len(rows)
    return count

#random selector function
#this function has two queries it will use the userid(s) input to select the rows in the restuarants table under the input.
#the 2nd query will only if all user(s) have at least 5 restaurants, if not the function will return with a message.
#If the user(s) have at least 5 restaurants it will select a random restaurant.
def view_restaurant_random(userid):
    all_restaurants = []
    for id in userid:
        view = (
            f"SELECT * FROM restaurants WHERE userid={id}"
        )
        cursor.execute(view)
        rows = cursor.fetchall()
        if len(rows) < 5: #Checking to see if user(s) have enough (5) resturants to randomize
            return f'User ID: {id} does not have enough restaurants to randomize' #output if user(s) don't have enough (5) resturants to randomize
        for restaurant in rows:
            all_restaurants.append(restaurant['restaurantuniqueid'])
    selected = random.choice(all_restaurants)
    view = (
        "SELECT restaurants.restaurantname, restaurants.restaurantuniqueid, users.firstname, users.lastname, users.userid\n"
        "FROM restaurants\n"
        "INNER JOIN users ON restaurants.userid=users.userid\n"
        f"WHERE restaurants.restaurantuniqueid = '{selected}'"
    )
    try:
        cursor.execute(view)
        rows = cursor.fetchall()
    except Error as e:
        print(f"The error '{e}' occurred")
    return rows
#ids = [2827, 37715, 60464, 71446]
#view_restaurant_random(ids)





#prof functions
def execute_query(connection, query):
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        connection.commit()
        print("Query executed successfully")
    except Error as e:
        print(f"The error '{e}' occurred")

def execute_read_query(connection, query):
    cursor = connection.cursor(dictionary=True)
    result = None
    try:
        cursor.execute(query)
        result = cursor.fetchall()
        return result
    except Error as e:
        print(f"The error '{e}' occurred")
