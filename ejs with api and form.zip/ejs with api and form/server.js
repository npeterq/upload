// load the things we need
var express = require('express');
var app = express();
const bodyParser  = require('body-parser');

// required module to make calls to a REST API
const axios = require('axios');

var selectedID = "";
app.use(bodyParser.urlencoded());

// set the view engine to ejs
app.set('view engine', 'ejs');

// use res.render to load up an ejs view file

// index page done
app.get('/', function(req, res) {
    res.render('pages/index');
});

// get all users page done
app.get('/get_all_user', function(req, res) {

    axios.get('http://127.0.0.1:5000/api/users/all')
    .then((response)=>{
    console.log(response.data);
    var userlist = response.data;
        console.log(response.data);
        res.render('pages/get_all_user', {
            userlist: userlist
        })
    });   
});

// get specific users page done
app.get('/get_specific_user', function(req, res) {
    
    res.render("pages/get_specific_user");
});
// get specific users process done
app.post('/process_specific_user', function(req, res){
    var specific_user = req.body.specific_user;
    console.log("userid given is: " + specific_user);
    axios.get(`http://127.0.0.1:5000/api/users/id?userid=${specific_user}`)
    .then((response)=>{
    var specific_user_info = response.data;
    console.log(response.data);
    res.render('pages/get_specific_user', {
        specific_user_info: specific_user_info
    })
    });
})

// add user page done
app.get('/add_user', function(req, res) {
    
    res.render("pages/add_user");
});

// add user process done
app.post('/process_add_user', function(req, res){
    var uifirstname = req.body.user_firstname;
    var uilastname = req.body.user_lastname;
    console.log("name given is: " + uifirstname + " " + uilastname);
    axios.post(`http://127.0.0.1:5000/api/users/create`, {
        firstname: uifirstname,
        lastname: uilastname
    })
    .then((response)=>{
    var message = response.data;
    console.log(response.data);
    res.render('pages/add_user', {
        response_message: message
    })
    });
})


// update user page done
app.get('/update_user', function(req, res) {
    
    res.render("pages/update_user");
});

// add user process done
app.post('/process_update_user', function(req, res){
    var ui_userid = req.body.user_id;
    var uifirstname = req.body.new_firstname;
    var uilastname = req.body.new_lastname;
    var uichoice = req.body.choice;
    console.log("firstname given is: " + uifirstname);
    console.log("lastname given is: "+ uilastname);
    console.log("userid is " + ui_userid + " and choice is " + uichoice);
    axios.post(`http://127.0.0.1:5000/api/users/update`, {
        newfirstname: uifirstname,
        newlastname: uilastname,
        userid: ui_userid,
        option: uichoice
    })
    .then((response)=>{
    var message = response.data;
    console.log(response.data);
    res.render('pages//update_user', {
        response_message: message
    })
    })
    .catch((error)=>{
        console.log(error)}
    )
})

// update restaurant page done
app.get('/update_restaurant', function(req, res) {
    res.render("pages/update_restaurant");
});

// update restaurant process done
app.post('/process_update_restaurant', function(req, res){
    var ui_userid = req.body.user_id;
    var uirestaurantid = req.body.restaurantid;
    var uinewname = req.body.newname;
    console.log("restaurantid given is: " + uirestaurantid);
    console.log("newname given is: "+ uinewname);
    console.log("userid is " + ui_userid);
    axios.post(`http://127.0.0.1:5000/api/restaurants/update`, {
        newname: uinewname,
        restaurantid: uirestaurantid,
        userid: ui_userid
    })
    .then((response)=>{
    var message = response.data;
    console.log(response.data);
    res.render('pages/update_restaurant', {
        response_message: message
    })
    })
    .catch((error)=>{
        console.log(error)}
    )
})

// random restaurant page done
app.get('/random_restaurant', function(req, res) {
    res.render("pages/random_restaurant");
});

/*
// random restaurant process done
app.post('/process_random_restaurant', function(req, res){
    var ui_userid = req.body.user_id;
    var ui_userid1 = ui_userid.replace(/'/g,'');
    console.log(ui_userid1);
    })
*/

// random restaurant process done
app.post('/process_random_restaurant', function(req, res){
    var ui_userid = req.body.user_id;
    console.log("userid(s) given " + ui_userid);
    axios.post(`http://127.0.0.1:5000/api/restaurants/random`, {
        userid: [ui_userid]
    })
    .then((response)=>{
    var message = response.data;
    console.log(response.data);
    res.render('pages/random_restaurant', {
        response_message: message,
    })
    })
    .catch((error)=>{
        console.log(error)}
    )
})




app.listen(8080);
console.log('8080 is the magic port');
