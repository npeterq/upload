import flask
from finalprojfunctions import (add_user, add_restaurants, delete_restaurant, view_restaurant_id, edit_name,
                                  edit_restaurant,
                                  create_connection, execute_read_query, delete_restaurant, view_restaurant_all_info,
                                  view_restaurants, view_restaurant_random)
from flask import jsonify
from flask import request, make_response
#PETER NGUYEN AND DAN DOAN




#view specific user check http://127.0.0.1:5000/api/users/id                                      GET    
#view all users check http://127.0.0.1:5000/api/users/all                                         GET
#add user check http://127.0.0.1:5000/api/users/create                                            POST
#edit/update name/update user check http://127.0.0.1:5000/api/users/update                        POST
#view all restaurant added by specific userid check http://127.0.0.1:5000/api/restaurants/id      GET
#view all restaurants added so far in db check http://127.0.0.1:5000/api/restaurants/all          GET
#add restaurants check http://127.0.0.1:5000/api/restaurants/add                                  POST
#edit/update restaurant http://127.0.0.1:5000/api/restaurants/update                              POST
#delete restaurant check http://127.0.0.1:5000/api/restaurants/delete                             POST
#random restaurant check http://127.0.0.1:5000/api/restaurants/random                             POST


#>>>>   VIEW ALL INFORMATION REGARDING BOTH TABLE http://127.0.0.1:5000/api/restaurants/all/all   GET <<<<<


#setting up an application name
app = flask.Flask(__name__)#sets up application
app.config["DEBUG"] = True #allow to show erroes in browsers


@app.route('/', methods=['GET'])#default path
def home():
    return "<h1>Welcome to the first part of our project</h1>"


#this route below will ask for userid in the parameters, and the result will send back the information of the userid given
@app.route('/api/users/id', methods=['GET'])
def api_users_id():
    if 'userid' in request.args:
        userid = int(request.args['userid'])
    else:
        return 'ERROR: No ID Provided!'
    conn = create_connection("cis3368.cnul0adngz4b.us-east-2.rds.amazonaws.com", "admin", "Weplaygames123!", "cis3368finalproject") #Info to connect to DB
    sql = "SELECT * FROM users"
    users = execute_read_query(conn, sql)
    results = []
    for user in users:
        if user['userid'] == userid:
            results.append(user)
    return jsonify(results)
#^^ in parameters set userid to a userid to get their info


#this route below will send back all the users in the users table
@app.route('/api/users/all', methods=['GET'])
def api_users_all():
    conn = create_connection("cis3368.cnul0adngz4b.us-east-2.rds.amazonaws.com", "admin", "Weplaygames123!", "cis3368finalproject") #Info to connect to DB
    sql = "SELECT * FROM users"
    users = execute_read_query(conn, sql)
    results = []
    for user in users:
        results.append(user)
    return jsonify(results)
#no need for input its a get, as long as they go to the correct link


#below adds users, just ask for json firstname and lastname, will automatically create a unique key and id for user 
@app.route('/api/users/create', methods=['POST'])
def api_user_create():
    request_data = request.get_json() #requesting json
    fname = request_data['firstname']
    lname = request_data['lastname']
    add_user(fname, lname)  #adding first and lastname to the sql query
    return 'User added request worked'
#example below, change test-two and api-test to change the firstname and lastname of the user
#in body
#{
#    "firstname":"test-two",
#    "lastname":"api-test"
#}

#below update users, just ask for json firstname and lastname, option 
@app.route('/api/users/update', methods=['POST'])
def api_user_update():
    request_data = request.get_json() #requesting json
    userid = request_data['userid']#ask for which user to change
    option = request_data['option']#ask for option, 1 to change firstname, 2 to change lastname, if no change = empty
    option = int(option)
    fname = request_data['newfirstname']
    lname = request_data['newlastname']
    edit_name(userid, option, fname, lname) #adding the userid, option, fname, lname to the sql query
    return 'User update request worked'
#example below
#In body
#{
#    "userid":71157,
#    "option": 1,
#    "newfirstname":"test-two",
#    "newlastname":""  << we leave this empty because its not going to change
#}
#^^ if want to change lastname, change option to 2, then leave firstname empty instead


#route below asks for userid in parameters, and will return json list of all restaurant added by the user with the id
@app.route('/api/restaurants/id', methods=['GET'])
def api_restaurant_id():
    if 'userid' in request.args:
        userid = int(request.args['userid'])
    else:
        return 'ERROR: No ID Provided!'
    results = view_restaurant_id(userid)
    return jsonify(results)
#^^ in parameters

#this route below will send back all the restaurantss in the restraurants table
@app.route('/api/restaurants/all', methods=['GET'])
def api_restaurants_all():
    restaurants = view_restaurants()
    results = []
    for user in restaurants:
        results.append(user)
    return jsonify(results)
#no need for input its a get, as long as they go to the correct link


#this route below will send back all the restaurantss in the restraurants table
@app.route('/api/restaurants/all/all', methods=['GET'])
def api_restaurants_all_all():
    restaurants = view_restaurant_all_info()
    results = []
    for user in restaurants:
        results.append(user)
    return jsonify(results)
#no need for input its a get, as long as they go to the correct link


#route below add single restaurant at a time, using json body format, will ask for the user id and then the name of the restaurant
#it will also tells the user how many restaurant they have currently, and will ask them to add until they have between 5 and 10
@app.route('/api/restaurants/add', methods=['POST'])
def api_restaurant_add():
    request_data = request.get_json()
    userid = request_data['userid']#ask for which user to add
    restaurantname = request_data['restaurantname']
    current_amount_restaurant = add_restaurants(userid, restaurantname)
    return f'Your current amount of restaurant is {current_amount_restaurant}, please add until you have between 5 and 10.'
# ^^ in body json
#
#{
#    "userid":2827,
#    "restaurantname": "taco"
#}



#below update restaurant, just ask for json userid and restaurantid, then ask for the name of the new restaurant 
@app.route('/api/restaurants/update', methods=['POST'])
def api_restaurant_update():
    request_data = request.get_json()
    userid = request_data['userid']#ask for which user to change
    restaurantid = request_data['restaurantid']#ask for restaurant id to change its name
    newname = request_data['newname']#ask for name of new restaurant
    edit_restaurant(userid, restaurantid, newname) #adding userid, restaurantid, newname to sql query
    return 'Restaurant update request worked'
#example below
#will change the name of the restaurant with the ID of 29 to fries in the example
#{
#    "userid":71157,
#    "restaurantid": 29,
#    "newname": "fries"
#}

#below will remove restaurant with the matching userid and restaurantuniqueid
@app.route('/api/restaurants/delete', methods=['POST'])
def api_restaurant_delete():
    request_data = request.get_json()
    userid = request_data['userid']#ask for which user to change
    restaurantid = request_data['restaurantid']#ask for restaurant id to change its name
    amount = delete_restaurant(userid, restaurantid) #adding userid, restaurantid to sql query
    return f'Restaurant removal request worked, you currently have {amount} restaurants, please add more if you have less than 5.'

#example
#{
#    "userid":71157,
#    "restaurantid": 28
#}
#it will tell the user how many restaurant they have at the end so they can add more if they have less than 5 after deletion

#below will select one random resturant with the matching userid(s) inputed
@app.route('/api/restaurants/random', methods=['POST'])
def api_restaurants_random():
    request_data = request.get_json() #requesting json
    userid = request_data['userid'] #requesting userid via json
    if '"' in userid:
        userid = userid.remove('"', "'")
        random = view_restaurant_random(userid)
    elif "'" in userid:
        userid = userid.remove('"', "'")
        random = view_restaurant_random(userid)
    else:
        random = view_restaurant_random(userid)
    return jsonify(random) #using view_restaurant_random function to get return output

#need user to input a list of id on POST body of url
#{
#        "userid": [2827, 37715, 60464, 71446]
#}




app.run()
